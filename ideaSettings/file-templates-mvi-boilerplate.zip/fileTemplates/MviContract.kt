#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import kotlinx.coroutines.flow.Flow
import com.airwallex.core.util.mergeWith
import com.airwallex.core.util.toFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.map
import com.airwallex.feature.shared.error.genericErrorMessage
import com.airwallex.core.mvi.*
import com.airwallex.core.mvi.MviResult.ProcessStatus
import com.airwallex.core.mvi.MviResult.ProcessStatus.*
import com.airwallex.core.util.TextHolder
import javax.inject.Inject
import ${PACKAGE_NAME}.${FEATURE_NAME}Contract.*
import com.airwallex.feature.shared.navigation.ScreenNavAction

class ${FEATURE_NAME}Contract @Inject constructor(
        // TODO, might need integration apollo data source
        // TODO, or might need read data from local db/preferences/files
) : MviContract<Event, ViewState, ViewEffect, Result>() {
    /***********************************************
     *               event processing              *
     ***********************************************/

    /**
     * TODO, add more processing for different events
     * 1. event could be a data class to carry parameters from UI
     * 2. event could be an object, for example, trigger data loading
     */
    override val eventProcessor: MviEventProcessor<Event, Result> = MviEventProcessor { event ->
        when (event) {
            is Event.LoadDataEvent -> processLoadData()
        }
    }

    /**
     * TODO, integration with actual api call or local pref/db read
     */
    private fun processLoadData(): Flow<Result> =
        Result.LoadDataResult(processStatus = SUCCESS,).toFlow() // mock up success
            .onStart { delay(500) } // mock up api call delay
            .mergeWith(Result.LoadDataResult(IN_FLIGHT).toFlow()) // show fullscreen loading

    /***********************************************
     *               state reducing                *
     ***********************************************/

    /**
     * Reduce to a new view state from the previous view state and the fetched result data
     */
    override val stateReducer: MviStateReducer<Result, ViewState> = MviStateReducer { prevState, result ->
        when (result) {
            is Result.LoadDataResult -> reduceLoadDataResult(prevState, result)
            is Result.NoResult -> prevState
        }
    }

    private fun reduceLoadDataResult(prevState: ViewState, result: Result.LoadDataResult): ViewState =
            when (result.processStatus) {
                IN_FLIGHT -> ViewState.Loading // used for full screen loading
//                IN_FLIGHT -> ViewState.Content(data = EMPTY.copy(isRefreshing = true)) // used for shimmer loading effect
                SUCCESS -> ViewState.Content(data = prepareDisplayableData(prevState = prevState, rawData = result.rawData!!))
                FAILURE -> ViewState.Error(genericErrorMessage)
                else -> prevState
            }

    private fun prepareDisplayableData(prevState: ViewState, rawData: Any): ViewData {
        // TODO, process raw data into displayable data
        return ViewData.EMPTY
    }

    /***********************************************
     *               effect mapping                *
     ***********************************************/

    override val effectMapper: MviEffectMapper<Result, ViewEffect> = MviEffectMapper { result ->
        when (result) {
            is Result.LoadDataResult -> ViewEffect.NoEffect
            else -> ViewEffect.NoEffect
        }
    }

    /***********************************************
     *           contract components               *
     ***********************************************/

    /**
     * event
     */
    sealed class Event : MviEvent {
        object LoadDataEvent : Event()
    }

    /**
     * side effect
     */
    sealed class ViewEffect : MviViewEffect {
        data class NavigateEffect(val navAction: ScreenNavAction) : ViewEffect() // TODO, create this effect if it needs a top bar
        object NoEffect : ViewEffect()
    }

    /**
     * Result
     */
    sealed class Result(override val processStatus: ProcessStatus) : MviResult {
        data class LoadDataResult(
                override val processStatus: ProcessStatus,
                val rawData: Any? = null, // raw data that get from remote or local data source
                val exception: Exception? = null
        ) : Result(processStatus)

        object NoResult : Result(SUCCESS)
    }

    /**
     * View state
     */
    sealed class ViewState(override val status: MviViewState.Status) : MviViewState {
        object Idle : ViewState(status = MviViewState.Status.IDLE)
        object Loading : ViewState(status = MviViewState.Status.LOADING) // optional, used for full screen loading, can be delete if screen needs shimmer effect
        data class Content(val data: ViewData) : ViewState(status = MviViewState.Status.CONTENT)
        data class Error(val errorMsg: TextHolder) : ViewState(status = MviViewState.Status.ERROR)
    }

    /**
     * View data
     */

    data class ViewData(
            val isRefreshing: Boolean, // optional, used for screen that need shimmer effect
            val displayableData: Any // displayable data, should be able being used directly by compose layer
    ) {
        companion object {
            val EMPTY = ViewData(
                    isRefreshing = false,
                    displayableData = Unit
            )
        }
    }
}