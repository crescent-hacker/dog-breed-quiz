#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import money.tiiik.feature.core.navigation.NavigateBack
import money.tiiik.feature.core.navigation.ScreenNavAction
import money.tiiik.feature.core.navigation.hiltMviViewModel
import money.tiiik.infra.compose.ui.util.RepeatWhenStarted
import ${PACKAGE_NAME}.${FEATURE_NAME}Contract.*

@Composable
fun ${FEATURE_NAME}Screen(
        viewModel: ${FEATURE_NAME}ViewModel = hiltMviViewModel(),
        onNav: (ScreenNavAction) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val viewState by remember { viewModel.viewState }

    LaunchedEffect(viewState) {
        if (viewState == ViewState.Idle) {
            viewModel.loadData()
        }
    }

    RepeatWhenStarted {
        scope.launch {
            viewModel.viewEffects
                    .collectLatest {
                        when (it) {
                            ViewEffect.NavigateBackEffect -> onNav(NavigateBack)
                            else -> Unit
                        }
                    }
        }
    }

    ${FEATURE_NAME}UI(
            ctx = ctx,
            scope = scope,
            onNav = onNav,
            viewModel = viewModel,
            viewState = viewState
    )
}