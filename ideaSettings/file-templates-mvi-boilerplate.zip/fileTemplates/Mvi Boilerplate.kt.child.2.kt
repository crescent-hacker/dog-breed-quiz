#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.material.Text
import kotlinx.coroutines.CoroutineScope
import com.airwallex.dogquiz.ui.widget.FullScreenLoader
import com.airwallex.feature.shared.navigation.ScreenNavAction
import com.airwallex.feature.shared.ui.component.GenericErrorStateUI
import com.airwallex.feature.shared.ui.component.ThemeScreenContainer
import com.airwallex.core.designsystem.widget.TopAppBar
import ${PACKAGE_NAME}.${FEATURE_NAME}Contract.*

@Composable
fun ${FEATURE_NAME}UI(
        ctx: Context,
        scope: CoroutineScope,
        onNav: (ScreenNavAction) -> Unit, //TODO, change NavAction to XXXNavAction if u have a XXXNavGraph
        viewModel: ${FEATURE_NAME}ViewModel,
        viewState: ViewState
) {
    ThemeScreenContainer {
        // TODO, add top bar if not a overview page
        TopAppBar(onNavIconClicked = { viewModel.navigationBack() })

        when (viewState) {
            // TODO, if using shimmer loading, could delete this full screen loader,
            //  use Content viewState and ViewState.data.isRefreshing combination to control
            //  shimmer behavior
            is ViewState.Loading -> FullScreenLoader()
            is ViewState.Content -> ContentUI(ctx, scope, viewModel, viewState.data)
            is ViewState.Error -> GenericErrorStateUI()

            else -> Unit
        }
    }
}

@Composable
private fun ContentUI(
        ctx: Context,
        scope: CoroutineScope,
        viewModel: ${FEATURE_NAME}ViewModel,
        viewData: ViewData
) {
    Column(
            modifier = Modifier
                    .fillMaxSize(),
    ) {
        // TODO, add UI content here
        Text(
            text = "${FEATURE_NAME} Screen",
            style = MaterialTheme.typography.h1
        )
    }
}
