#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME}#end

import dagger.hilt.android.lifecycle.HiltViewModel
import money.tiiik.feature.core.ui.base.AbstractMviViewModel
import javax.inject.Inject
import ${PACKAGE_NAME}.${FEATURE_NAME}Contract.*

@HiltViewModel
class ${FEATURE_NAME}ViewModel @Inject constructor(
        private val contract: ${FEATURE_NAME}Contract
): AbstractMviViewModel<Event, ViewState, ViewEffect, Result>() {
    override fun getInitViewState(): ViewState = ViewState.Idle
    override fun getContract(): ${FEATURE_NAME}Contract = contract

    fun loadData() {
        dispatchEvent(Event.LoadDataEvent)
    }

    fun navigationBack() {
        dispatchSideEffect(ViewEffect.NavigateBackEffect)
    }
}